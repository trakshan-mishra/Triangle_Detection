 Extract the Folder
Install Flask (pip install flask)
run the file  (python app.py)
run the local server by copying locl link
