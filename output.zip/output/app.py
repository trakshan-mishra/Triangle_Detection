from flask import Flask, render_template, Response
import cv2 as cv
import numpy as np

app = Flask(__name__)

def shapeDetector(image):
    # Convert to grayscale
    gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)

    # Apply GaussianBlur to reduce noise and improve edge detection
    blurred = cv.GaussianBlur(gray, (5, 5), 0)

    # Apply Canny edge detection
    edged = cv.Canny(blurred, 30, 150)  # Adjusted thresholds

    # Find contours in the edge map
    contours, _ = cv.findContours(edged, cv.RETR_EXTERNAL, cv.CHAIN_APPROX_SIMPLE)

    for cnt in contours:
        shape = detect(cnt)
        if shape == "triangle":
            M = cv.moments(cnt)
            if M["m00"] != 0:
                cX = int((M["m10"] / M["m00"]))
                cY = int((M["m01"] / M["m00"]))
            else:
                cX, cY = 0, 0
            cv.drawContours(image, [cnt], -1, (34, 0, 156), 2)
            cv.putText(image, shape, (cX, cY), cv.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

    return image

def detect(c):
    shape = "unidentified"
    peri = cv.arcLength(c, True)
    approx = cv.approxPolyDP(c, 0.04 * peri, True)
    if len(approx) == 3:
        shape = "triangle"
    return shape

def gen_frames():
    cap_video = cv.VideoCapture(0)
    while True:
        success, frame = cap_video.read()
        if not success:
            break
        else:
            frame = shapeDetector(frame)
            ret, buffer = cv.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

    cap_video.release()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video_feed')
def video_feed():
    return Response(gen_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=5000, debug=True)

